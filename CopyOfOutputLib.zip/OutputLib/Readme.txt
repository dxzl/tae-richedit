Copy of the library files in:
C:\Program Files (x86)\Borland\Cbuilder4\PROJECTS\Bpl

or

$(BCB)\PROJECTS\Bpl

-----------------------------------------------
TaeRichEditComponent.tds are the Turbo Debugger symbols