//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "About.h"
#include "LogoMain.h"
#include "LogoStrs.h"
#include "MAPI.hpp"
#include "taerichedit.h"
#include "TaeRichEditAdvPrint.h"
#include "TaePreviewFrm.h"
//---------------------------------------------------------------------------
#pragma link "TaeRichEdit"
#pragma link "TaePrintDialog"
#pragma link "TaePageSetupDlg"
#pragma resource "*.dfm"
TLogoAppForm *LogoAppForm;
//---------------------------------------------------------------------------
__fastcall TLogoAppForm::TLogoAppForm(TComponent *Owner)
	: TForm(Owner)
{
	FFileName = LoadStr(sUntitled);
	Application->OnIdle = OnIdle;
	Caption = Application->Title + " - " + FFileName;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileNew1Execute(TObject *Sender)
{
	FFileName = LoadStr(sUntitled);
	TaeRichEdit1->FileName = FFileName;
	TaeRichEdit1->Lines->Clear();
	TaeRichEdit1->Modified = false;
	Caption = Application->Title + " - " + FFileName;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileOpen1Execute(TObject *Sender)
{
	if (OpenDialog->Execute())
	{
		TaeRichEdit1->Lines->LoadFromFile(OpenDialog->FileName);
		FFileName = OpenDialog->FileName;
		TaeRichEdit1->FileName = FFileName;
		TaeRichEdit1->SetFocus();
		TaeRichEdit1->Modified = false;
		TaeRichEdit1->ReadOnly = OpenDialog->Options.Contains(ofReadOnly);
		Caption = Application->Title + " - " + FFileName;
	}
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSave1Execute(TObject *Sender)
{
	if (FFileName == LoadStr(sUntitled))
		FileSaveAs1Execute(Sender);
	else
	{
		TaeRichEdit1->Lines->SaveToFile(FFileName);
		TaeRichEdit1->Modified = false;
	}
	TaeRichEdit1->FileName = FFileName;
	Caption = Application->Title + " - " + FFileName;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSaveAs1Execute(TObject *Sender)
{
	String str;
	TVarRec vrs[1];

	if (SaveDialog->Execute())
	{
		if (FileExists(SaveDialog->FileName))
		{
			str = FmtLoadStr(sOverwrite, OPENARRAY(TVarRec, (SaveDialog->FileName)));
			if (MessageDlg(str, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo <<
				mbCancel, 0) != IDYES)
				return;
		}
		TaeRichEdit1->Lines->SaveToFile(SaveDialog->FileName);
		FFileName = SaveDialog->FileName;
		TaeRichEdit1->Modified = false;
	}
	TaeRichEdit1->FileName = FFileName;
	Caption = Application->Title + " - " + FFileName;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSend1Execute(TObject *Sender)
{
	TMapiMessage MapiMessage;
	Cardinal MError;

	MapiMessage.ulReserved = 0;
	MapiMessage.lpszSubject = NULL;
	MapiMessage.lpszNoteText = TaeRichEdit1->Lines->Text.c_str();
	MapiMessage.lpszMessageType = NULL;
	MapiMessage.lpszDateReceived = NULL;
	MapiMessage.lpszConversationID = NULL;
	MapiMessage.flFlags = 0;
	MapiMessage.lpOriginator = NULL;
	MapiMessage.nRecipCount = 0;
	MapiMessage.lpRecips = NULL;
	MapiMessage.nFileCount = 0;
	MapiMessage.lpFiles = NULL;

	MError = MapiSendMail(0, 0, MapiMessage, MAPI_DIALOG | MAPI_LOGON_UI |
		MAPI_NEW_SESSION, 0);

	if (MError)
		MessageDlg(LoadStr(sSendError), mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileExit1Execute(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::HelpAbout1Execute(TObject *Sender)
{
	AboutBox->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FormatBold1Execute(TObject *Sender)
{
	TaeRichEdit1->SelAttributes->Bold2 =
		TaeRichEdit1->SelAttributes->Bold2 ? tsNo : tsYes;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FormatItalics1Execute(TObject *Sender)
{
	TaeRichEdit1->SelAttributes->Italic2 =
		TaeRichEdit1->SelAttributes->Italic2 ? tsNo : tsYes;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FormatUnderline1Execute(TObject *Sender)
{
	TaeRichEdit1->SelAttributes->Underline2 =
		TaeRichEdit1->SelAttributes->Underline2 ? tsNo : tsYes;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::EditUndo1Execute(TObject *Sender)
{
	TaeRichEdit1->Undo();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::EditRedo1Execute(TObject *Sender)
{
	TaeRichEdit1->Redo();
}
//---------------------------------------------------------------------------
// TLogoAppForm::OnIdle() is an example of how to enable/disable buttons and
// menu items.  it is horribly incomplete and is not intended to demonstrate
// all of the code needed to make this example fully functional.  as is, it
// manages only the buttons/menus for the undo/redo state of the control.
// there are many other ways to manage the button and menu states -- I just
// happen to use this one frequently.  you certainly may use other methods
// to accomplish this...
//
void __fastcall TLogoAppForm::OnIdle(TObject* Sender, bool& done)
{
	bool canUndo = TaeRichEdit1->CanUndo;
	bool canRedo = TaeRichEdit1->CanRedo;
	AnsiString undoStr = TaeRichEdit1->UndoTypeString;
	AnsiString redoStr = TaeRichEdit1->RedoTypeString;

	EditUndo1->Enabled = canUndo;
	EditRedo1->Enabled = canRedo;

	if (canUndo) EditUndo1->Caption = undoStr;
	if (canRedo) EditRedo1->Caption = redoStr;

	if (canUndo) EditUndo1->Hint = undoStr + "|" + undoStr;
	if (canRedo) EditRedo1->Hint = redoStr + "|" + redoStr;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphLeft1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Alignment2 = ta2LeftJustify;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphCenter1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Alignment2 = ta2Center;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphRight1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Alignment2 = ta2RightJustify;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphBullets1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2Bullet;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNoBullet1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2None;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNumbers1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2Arabic;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphBulletBtnClick(TObject *Sender)
{
	TNumberingType2 nt = TaeRichEdit1->Paragraph->Numbering2;

	nt = (TNumberingType2) (nt + 1);
	if (nt > nt2UcRoman) nt = nt2None;

	TaeRichEdit1->Paragraph->Numbering2 = nt;
	TaeRichEdit1->Paragraph->NumberingStart = 1;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphLcLetters1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2LcLetter;
	TaeRichEdit1->Paragraph->NumberingStart = 1;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphUcLetters1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2UcLetter;
	TaeRichEdit1->Paragraph->NumberingStart = 1;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphLcRoman1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2LcRoman;
	TaeRichEdit1->Paragraph->NumberingStart = 1;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphUcRoman1Execute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->Numbering2 = nt2UcRoman;
	TaeRichEdit1->Paragraph->NumberingStart = 1;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNsNoneExecute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->NumberingStyle = ns2None;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNsPeriodExecute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->NumberingStyle = ns2Period;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNsRParenExecute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->NumberingStyle = ns2RightParen;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphNsParensExecute(TObject *Sender)
{
	TaeRichEdit1->Paragraph->NumberingStyle = ns2Parens;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphSkipNumberingExecute(TObject *Sender)
{
	bool skip = TaeRichEdit1->Paragraph->SkipNumbering;
	TaeRichEdit1->Paragraph->SkipNumbering = !skip;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphJustified1Execute(TObject *Sender)
{
	TAlignment2 ta = (TAlignment2) (TaeRichEdit1->Paragraph->Alignment2 + 1);
	if (ta < ta2Justified || ta > ta2SnapGrid) ta = ta2Justified;
	TaeRichEdit1->Paragraph->Alignment2 = ta;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphIndent1Execute(TObject *Sender)
{
	int indent = TaeRichEdit1->Paragraph->FirstIndent2;
	indent += 720;
	TaeRichEdit1->Paragraph->FirstIndent2 = indent;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParagraphOutdent1Execute(TObject *Sender)
{
	int indent = TaeRichEdit1->Paragraph->FirstIndent2;
	indent -= 720;
	if (indent < 0) indent = 0;
	TaeRichEdit1->Paragraph->FirstIndent2 = indent;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::TestBtnClick(TObject *Sender)
{
	TaeRichEdit1->HideScrollBars = !TaeRichEdit1->HideScrollBars;
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::PrintPrint1Execute(TObject *Sender)
{
	TaePrintDialog1->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::PrintPreview1Execute(TObject *Sender)
{
	// note: return value indicates how the form was dismissed -- for example,
	// the user may have selected print or print setup.
	TaeRichEdit1->TaePrint->PaginateForPrinter = true;
	TModalResult mr = TaePreviewForm->Execute(TaeRichEdit1);
	switch (mr) {
		case mrAll + 1:
			PrintPrint1Execute(this);
			break;
		case mrAll + 2:
			PrintSetup1Execute(this);
			break;
		}
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::PageBreak1Click(TObject *Sender)
{
	TaeRichEdit1->Paragraph->PageBreakBefore =
		!TaeRichEdit1->Paragraph->PageBreakBefore;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::PrintSetup1Execute(TObject *Sender)
{
	TaePageSetupDialog1->Execute(TaeRichEdit1);
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::DLLVersionInfo1Click(TObject *Sender)
{
	TModuleVersionInfo* mvi;
	mvi = TaeRichEdit1->RichEditVersionInfo;

	AnsiString msg = AnsiString("Rich Edit Version: ") +
		AnsiString(TaeRichEdit1->RichEditVersion) + "\r\n(Major = " +
		AnsiString(mvi->Major) + "; Minor = " + AnsiString(mvi->Minor) +
		"; Release = " + AnsiString(mvi->Release) + "; Build = " +
		AnsiString(mvi->Build) + ")";

	ShowMessage(msg);
}
//---------------------------------------------------------------------------

