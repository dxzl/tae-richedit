//----------------------------------------------------------------------------
#ifndef LogoMainH
#define LogoMainH
//----------------------------------------------------------------------------
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Dialogs.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include "TaeRichEdit.h"
#include "TaePrintDialog.h"
#include "TaePageSetupDlg.h"
//----------------------------------------------------------------------------
class TLogoAppForm : public TForm
{
__published:
	TOpenDialog *OpenDialog;
	TSaveDialog *SaveDialog;
        TActionList *ActionList1;
        TAction *FileNew1;
        TAction *FileOpen1;
        TAction *FileSave1;
        TAction *FileSaveAs1;
        TAction *FileSend1;
        TAction *FileExit1;
        TEditCut *EditCut1;
        TEditCopy *EditCopy1;
        TEditPaste *EditPaste1;
        TAction *HelpAbout1;
        TImageList *ImageList1;
		TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *FileNewItem;
        TMenuItem *FileOpenItem;
        TMenuItem *FileSaveItem;
        TMenuItem *FileSaveAsItem;
        TMenuItem *N1;
        TMenuItem *FileSendItem;
        TMenuItem *FileExitItem;
        TMenuItem *CutItem;
        TMenuItem *CopyItem;
        TMenuItem *PasteItem;
        TMenuItem *Help1;
        TMenuItem *HelpAboutItem;
	TMenuItem *Test1;
	TMenuItem *RecreateWnd1;
	TCoolBar *CoolBar1;
	TToolBar *StandardTB;
	TToolButton *NewBtn;
	TToolButton *OpenBtn;
	TToolButton *SaveBtn;
	TToolButton *ToolButton10;
	TToolButton *PreviewBtn;
	TToolButton *PrintBtn;
	TToolButton *PageSetupBtn;
	TToolButton *ToolButton17;
	TToolButton *CutBtn;
	TToolButton *CopyBtn;
	TToolButton *PasteBtn;
	TToolButton *ToolButton12;
	TToolButton *UndoBtn;
	TToolButton *RedoBtn;
	TToolButton *ToolButton11;
	TToolButton *FindBtn;
	TToolButton *ReplaceBtn;
	TToolButton *SearchAgainBtn;
	TToolButton *ToolButton15;
	TToolButton *InsertDateBtn;
	TToolButton *ToolButton13;
	TToolButton *FontBtn;
	TToolButton *ToolButton14;
	TToolButton *CloseOneBtn;
	TToolBar *FormatTB;
	TComboBox *FontNameCB;
	TToolButton *ToolButton16;
	TComboBox *FontSizeCB;
	TToolButton *ToolButton18;
	TToolButton *BoldBtn;
	TToolButton *ItalicBtn;
	TToolButton *UnderscoreBtn;
	TToolButton *ColorBtn;
	TToolButton *ToolButton19;
	TToolButton *ParagraphLeftBtn;
	TToolButton *ParagraphCenterBtn;
	TToolButton *ParagraphRightBtn;
	TToolButton *ToolButton20;
	TToolButton *ParagraphBulletBtn;
	TToolButton *ToolButton21;
	TToolButton *IndentBtn;
	TToolButton *OutdentBtn;
	TToolButton *ToolButton22;
	TToolButton *TestBtn;
	TImageList *HotSmallIL;
	TImageList *AppIconLarge;
	TImageList *AppIconSmall;
	TImageList *FileIconsIL;
	TStatusBar *StatusBar;
	TMenuItem *Format1;
	TMenuItem *Bold1;
	TMenuItem *Italics1;
	TMenuItem *Underline1;
	TMenuItem *N3;
	TMenuItem *Font1;
	TMenuItem *Paragraph1;
	TMenuItem *Tabs1;
	TMenuItem *Search1;
	TMenuItem *Find1;
	TMenuItem *Replace1;
	TMenuItem *SearchAgain1;
	TAction *FindFind1;
	TAction *FindReplace1;
	TAction *FindRepeat1;
	TAction *FormatBold1;
	TAction *FormatItalics1;
	TAction *FormatUnderline1;
	TAction *EditUndo1;
	TAction *EditRedo1;
	TAction *FormatFont1;
	TAction *FormatColor1;
	TAction *ParagraphLeft1;
	TAction *ParagraphCenter1;
	TAction *ParagraphRight1;
	TAction *ParagraphBullets1;
	TAction *ParagraphIndent1;
	TAction *ParagraphOutdent1;
	TAction *PrintPreview1;
	TAction *PrintPrint1;
	TAction *PrintSetup1;
	TMenuItem *N4;
	TMenuItem *FilePrint1;
	TMenuItem *FilePreview1;
	TMenuItem *FilePageSetup1;
	TMenuItem *EditUndo2;
	TMenuItem *EditRedo2;
	TPopupMenu *PopupMenu1;
	TMenuItem *None1;
	TMenuItem *Bullets1;
	TMenuItem *ArabicNumbers1;
	TAction *ParagraphNoBullet1;
	TAction *ParagraphNumbers1;
	TMenuItem *LcLetters1;
	TMenuItem *UCLetters1;
	TMenuItem *LCRoman1;
	TMenuItem *UCRoman1;
	TAction *ParagraphLcLetters1;
	TAction *ParagraphUcLetters1;
	TAction *ParagraphLcRoman1;
	TAction *ParagraphUcRoman1;
	TAction *ParagraphNsRParen;
	TAction *ParagraphNsPeriod;
	TAction *ParagraphNsParens;
	TAction *ParagraphNsNone;
	TMenuItem *Style1;
	TMenuItem *None2;
	TMenuItem *RightParenthesis1;
	TMenuItem *Parenthesis1;
	TMenuItem *Period1;
	TAction *ParagraphSkipNumbering;
	TMenuItem *Skip1;
	TToolButton *ToolButton1;
	TAction *ParagraphJustified1;
	TMenuItem *PageBreak1;
	TTaePrintDialog *TaePrintDialog1;
	TTaePageSetupDialog *TaePageSetupDialog1;
	TMenuItem *DLLVersionInfo1;
	TTaeRichEdit *TaeRichEdit1;
	void __fastcall FileNew1Execute(TObject *Sender);
	void __fastcall FileOpen1Execute(TObject *Sender);
	void __fastcall FileSave1Execute(TObject *Sender);
	void __fastcall FileSaveAs1Execute(TObject *Sender);
	void __fastcall FileSend1Execute(TObject *Sender);
	void __fastcall FileExit1Execute(TObject *Sender);
	void __fastcall HelpAbout1Execute(TObject *Sender);
	void __fastcall FormatBold1Execute(TObject *Sender);
	void __fastcall FormatItalics1Execute(TObject *Sender);
	void __fastcall FormatUnderline1Execute(TObject *Sender);
	void __fastcall EditUndo1Execute(TObject *Sender);
	void __fastcall EditRedo1Execute(TObject *Sender);
	void __fastcall ParagraphLeft1Execute(TObject *Sender);
	void __fastcall ParagraphCenter1Execute(TObject *Sender);
	void __fastcall ParagraphRight1Execute(TObject *Sender);
	void __fastcall ParagraphBullets1Execute(TObject *Sender);
	void __fastcall ParagraphNoBullet1Execute(TObject *Sender);
	void __fastcall ParagraphNumbers1Execute(TObject *Sender);
	void __fastcall ParagraphBulletBtnClick(TObject *Sender);
	void __fastcall ParagraphLcLetters1Execute(TObject *Sender);
	void __fastcall ParagraphUcLetters1Execute(TObject *Sender);
	void __fastcall ParagraphLcRoman1Execute(TObject *Sender);
	void __fastcall ParagraphUcRoman1Execute(TObject *Sender);
	void __fastcall ParagraphNsNoneExecute(TObject *Sender);
	void __fastcall ParagraphNsPeriodExecute(TObject *Sender);
	void __fastcall ParagraphNsRParenExecute(TObject *Sender);
	void __fastcall ParagraphNsParensExecute(TObject *Sender);
	void __fastcall ParagraphSkipNumberingExecute(TObject *Sender);
	void __fastcall ParagraphJustified1Execute(TObject *Sender);
	void __fastcall ParagraphIndent1Execute(TObject *Sender);
	void __fastcall ParagraphOutdent1Execute(TObject *Sender);
	void __fastcall TestBtnClick(TObject *Sender);
	void __fastcall PrintPrint1Execute(TObject *Sender);
	void __fastcall PrintPreview1Execute(TObject *Sender);
	void __fastcall PageBreak1Click(TObject *Sender);
	void __fastcall PrintSetup1Execute(TObject *Sender);
	void __fastcall DLLVersionInfo1Click(TObject *Sender);
private:
	AnsiString FFileName;
public:
	virtual __fastcall TLogoAppForm(TComponent *Owner);
	void __fastcall OnIdle(TObject* Sender, bool &done);
};
//----------------------------------------------------------------------------
extern TLogoAppForm *LogoAppForm;
//----------------------------------------------------------------------------
#endif    
