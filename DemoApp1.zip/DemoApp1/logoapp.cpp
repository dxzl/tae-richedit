//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------
USEFORM("LogoMain.cpp", LogoAppForm);
USERC("LogoStrs.rc");
USERES("LogoApp.res");
USEFORM("about.cpp", AboutBox);
USEFORM("..\Extras\Preview Form\TaePreviewFrm.cpp", TaePreviewForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	Application->Initialize();
	Application->Title = "TaeRichEditComponent Sample";
		Application->CreateForm(__classid(TLogoAppForm), &LogoAppForm);
		Application->CreateForm(__classid(TAboutBox), &AboutBox);
		Application->CreateForm(__classid(TTaePreviewForm), &TaePreviewForm);
		Application->Run();

	return 0;
}
//---------------------------------------------------------------------


