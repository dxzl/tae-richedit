//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "About.h"
#include "LogoMain.h"
#include "LogoStrs.h"
#include "MAPI.hpp"
//---------------------------------------------------------------------------
#pragma link "TaeRichEdit"
#pragma resource "*.dfm"
TLogoAppForm *LogoAppForm;
//---------------------------------------------------------------------------
__fastcall TLogoAppForm::TLogoAppForm(TComponent *Owner)
	: TForm(Owner)
{
	// double buffer?  sadly, does not work (I am not surprised)
	//	RichEdit1->DoubleBuffered = true;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileNew1Execute(TObject *Sender)
{
	FFileName = LoadStr(sUntitled);
	RichEdit1->Lines->Clear();
	RichEdit1->Modified = false;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileOpen1Execute(TObject *Sender)
{
	if (OpenDialog->Execute())
	{
		RichEdit1->Lines->LoadFromFile(OpenDialog->FileName);
		FFileName = OpenDialog->FileName;
		RichEdit1->SetFocus();
		RichEdit1->Modified = false;
		RichEdit1->ReadOnly = OpenDialog->Options.Contains(ofReadOnly);

		// loaded new file -- parse all text
		if (RadioGroup1->ItemIndex)
			ParseLinksFaster(0, RichEdit1->GetTextLen());
		else
			ParseLinks(0, RichEdit1->GetTextLen());
	}
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSave1Execute(TObject *Sender)
{
	if (FFileName == LoadStr(sUntitled))
		FileSaveAs1Execute(Sender);
	else
	{
		RichEdit1->Lines->SaveToFile(FFileName);
		RichEdit1->Modified = false;
	}
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSaveAs1Execute(TObject *Sender)
{
	String str;
	TVarRec vrs[1];

	if (SaveDialog->Execute())
	{
		if (FileExists(SaveDialog->FileName))
		{
			str = FmtLoadStr(sOverwrite, OPENARRAY(TVarRec, (SaveDialog->FileName)));
			if (MessageDlg(str, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo <<
				mbCancel, 0) != IDYES)
				return;
		}
		RichEdit1->Lines->SaveToFile(SaveDialog->FileName);
		FFileName = SaveDialog->FileName;
		RichEdit1->Modified = false;
	}
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileSend1Execute(TObject *Sender)
{
	TMapiMessage MapiMessage;
	Cardinal MError;

	MapiMessage.ulReserved = 0;
	MapiMessage.lpszSubject = NULL;
	MapiMessage.lpszNoteText = RichEdit1->Lines->Text.c_str();
	MapiMessage.lpszMessageType = NULL;
	MapiMessage.lpszDateReceived = NULL;
	MapiMessage.lpszConversationID = NULL;
	MapiMessage.flFlags = 0;
	MapiMessage.lpOriginator = NULL;
	MapiMessage.nRecipCount = 0;
	MapiMessage.lpRecips = NULL;
	MapiMessage.nFileCount = 0;
	MapiMessage.lpFiles = NULL;

	MError = MapiSendMail(0, 0, MapiMessage, MAPI_DIALOG | MAPI_LOGON_UI |
		MAPI_NEW_SESSION, 0);

	if (MError)
		MessageDlg(LoadStr(sSendError), mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FileExit1Execute(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::HelpAbout1Execute(TObject *Sender)
{
	AboutBox->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FindWordBreakBtnClick(TObject *Sender)
{
	TButton* btn = dynamic_cast<TButton*>(Sender);
	if (!btn) {
		MessageBeep(0);
		return;
		}

	TWordBreakType wbType = wbLeft;

	if (btn == LeftBtn) 			wbType = wbLeft;
	else if (btn == LeftBrkBtn) 	wbType = wbLeftBreak;
	else if (btn == LeftWordBtn)	wbType = wbMoveWordLeft;
	else if (btn == RightBtn) 		wbType = wbRight;
	else if (btn == RightBrkBtn)	wbType = wbRightBreak;
	else if (btn == RightWordBtn)	wbType = wbMoveWordRight;
	else return;

	int pos = RichEdit1->FindWordBreak(wbType);
	RichEdit1->SelStart = pos;
	RichEdit1->SelLength = 0;
	RichEdit1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::SelectWordBtnClick(TObject *Sender)
{
	RichEdit1->SelectWord();
}
//---------------------------------------------------------------------------
char *LinkText[] = { "brillig", "slithey", "wraths" };
int LinkTextSize[] = { 7, 7, 6 };

// slow parsing???
void __fastcall TLogoAppForm::ParseLinks(int startPos, int length)
{
	// TTaeRichEdit->Lines->EndUpdate() generates a CM_TEXTCHANGED
	// message (out of TTaeRichEditStrings) which is not suppressed
	// by setting TTaeRichEdit->EnableNotifications to false.  I
	// will fix this later.  in the meantime, we simply prevent
	// recursion by testing EnableNotifications....
	if (!RichEdit1->EnableNotifications) return;
	TNotifyEvent onChange = RichEdit1->OnChange;
	RichEdit1->OnChange = 0;

	// save starting position and length
	int selStart = RichEdit1->SelStart;
	int selLength = RichEdit1->SelLength;

	// disable events before changing anything.  warning: disabling
	// the events means that the TTaeRichEdit component SelStart, etc.,
	// properties are not updated.  we must, therefore, use properties
	// carefully...
	RichEdit1->EnableNotifications = false;

	// disable redrawing while parsing
	RichEdit1->Lines->BeginUpdate();

	// arbitrarily, back up two "words" before startPos and extend
	// to two "words" after ending position
	int endPos = startPos + length;
	if (RichEdit1->GetTextLen() <= endPos) endPos = RichEdit1->GetTextLen() - 1;
	startPos = RichEdit1->FindWordBreak(wbMoveWordLeft, startPos);
	startPos = RichEdit1->FindWordBreak(wbMoveWordLeft, startPos);
	endPos = RichEdit1->FindWordBreak(wbMoveWordRight, endPos);
	endPos = RichEdit1->FindWordBreak(wbMoveWordRight, endPos);
	if (RichEdit1->GetTextLen() <= endPos) endPos = RichEdit1->GetTextLen() - 1;

	// clear the link format for all text in range
	RichEdit1->SelStart = startPos;
	RichEdit1->SelLength = endPos - startPos;
	RichEdit1->SelAttributes->Link = tsNo;

	// for debugging
#if 0
	AnsiString msg("Parsing from ");
	msg += AnsiString(startPos) + " to " + AnsiString(endPos);
	msg += " using ParseLinks()";
	ShowMessage(msg);
#endif

	// test each word in range against LinkText values
	while (startPos < endPos) {
		// select an entire "word"
		startPos = RichEdit1->SelectWord(startPos);

		// compare selected text against link text
		AnsiString selectedText = RichEdit1->SelText;
		for (int i = 0; i < sizeof(LinkText) / sizeof(char*); i++) {
			if (!selectedText.AnsiCompare(LinkText[i])) {
				// got match.  link.
				RichEdit1->SelAttributes->Link = tsYes;
				break;
				}
			}

		// move to next word (if we do not move, then we are hung)
		startPos = RichEdit1->FindWordBreak(wbMoveWordRight, startPos);
		}

	// force resync of SelStart, et al???
	RichEdit1->SelStart = selStart;
	RichEdit1->SelLength = selLength;

	// enable redrawing
	RichEdit1->Lines->EndUpdate();

	// enable events
	RichEdit1->EnableNotifications = true;

	// restore OnChange handler
	RichEdit1->OnChange = onChange;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::ParseLinksFaster(int startPos, int length)
{
	// TTaeRichEdit->Lines->EndUpdate() generates a CM_TEXTCHANGED
	// message (out of TTaeRichEditStrings) which is not suppressed
	// by setting TTaeRichEdit->EnableNotifications to false.  I
	// will fix this later.  in the meantime, we simply prevent
	// recursion by testing EnableNotifications....
	if (!RichEdit1->EnableNotifications) return;
	TNotifyEvent onChange = RichEdit1->OnChange;
	RichEdit1->OnChange = 0;

	// save starting position and length
	int selStart = RichEdit1->SelStart;
	int selLength = RichEdit1->SelLength;

	// disable events before changing anything.  warning: disabling
	// the events means that the TTaeRichEdit component SelStart, etc.,
	// properties are not updated.  we must, therefore, use properties
	// carefully...
	RichEdit1->EnableNotifications = false;

	// disable redrawing while parsing
	::SendMessage(RichEdit1->Handle, WM_SETREDRAW, false, 0);

	// arbitrarily, back up two "words" before startPos and extend
	// to two "words" after ending position to ensure that, if starting
	// in the middle of a word, we get the entire word.  consider,
	// for example, what would happen if the user pastes text into
	// the middle of a word....
	int endPos = startPos + length;
	if (RichEdit1->GetTextLen() <= endPos) endPos = RichEdit1->GetTextLen() - 1;
	startPos = RichEdit1->FindWordBreak(wbMoveWordLeft, startPos);
	startPos = RichEdit1->FindWordBreak(wbMoveWordLeft, startPos);
	endPos = RichEdit1->FindWordBreak(wbMoveWordRight, endPos);
	endPos = RichEdit1->FindWordBreak(wbMoveWordRight, endPos);
	if (RichEdit1->GetTextLen() <= endPos) endPos = RichEdit1->GetTextLen() - 1;

	// for debugging
#if 0
	AnsiString msg("Parsing from ");
	msg += AnsiString(startPos) + " to " + AnsiString(endPos);
	msg += " using ParseLinksFaster()";
	ShowMessage(msg);
#endif

	// clear the link format for all text in range
	RichEdit1->SelStart = startPos;
	RichEdit1->SelLength = endPos - startPos;
	RichEdit1->SelAttributes->Link = tsNo;

	// test each word in range against LinkText values
	AnsiString selText = RichEdit1->SelText;
	int offset = 0;
	while (startPos + offset < endPos) {
		char* ptr = selText.c_str() + offset;

		// compare selected text against link text
		for (int i = 0; i < sizeof(LinkText) / sizeof(char*); i++) {
			if (!memcmp(ptr, LinkText[i], LinkTextSize[i]) &
				!isalnum(ptr[LinkTextSize[i]])) {
				RichEdit1->SelStart = startPos + offset;
				RichEdit1->SelLength = LinkTextSize[i];
				RichEdit1->SelAttributes->Link = tsYes;
				offset += LinkTextSize[i];
				break;
				}
			}

		offset++;
		}

	// force resync of SelStart, et al???
	RichEdit1->SelStart = selStart;
	RichEdit1->SelLength = selLength;

	// enable redrawing
	::SendMessage(RichEdit1->Handle, WM_SETREDRAW, true, 0);

	// enable events
	RichEdit1->EnableNotifications = true;

	// restore OnChange handler
	RichEdit1->OnChange = onChange;
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::FormShow(TObject *Sender)
{
	RichEdit1->Lines->LoadFromFile("sample.txt");

	// loaded new file -- parse all text
	if (RadioGroup1->ItemIndex)
		ParseLinksFaster(0, RichEdit1->GetTextLen());
	else
		ParseLinks(0, RichEdit1->GetTextLen());
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::RichEdit1UrlClick(TObject *Sender,
	  AnsiString urlText)
{
	// do something with this link click
	AnsiString msg("This link was clicked: \"");
	msg += RichEdit1->SelText;
	msg += "\".";
	Application->MessageBox(msg.c_str(), "Link Clicked", MB_OK);
}
//---------------------------------------------------------------------------
void __fastcall TLogoAppForm::RichEdit1Change(TObject *Sender)
{
	if (!RichEdit1->EnableNotifications) return;
	if (RadioGroup1->ItemIndex)
		ParseLinksFaster(RichEdit1->SelStart, RichEdit1->SelLength);
	else
		ParseLinks(RichEdit1->SelStart, RichEdit1->SelLength);
}
//---------------------------------------------------------------------------

